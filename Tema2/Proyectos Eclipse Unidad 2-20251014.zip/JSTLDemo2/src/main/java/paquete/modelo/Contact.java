package paquete.modelo;

public class Contact implements Comparable<Contact> {
	private String name, phone;

	public Contact(String name, String phone) {
		super();
		this.name = name;
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return name +": "+ phone;
	}

	@Override
	public int compareTo(Contact o) {
		return name.compareTo(o.name);
	}
	
	
}
