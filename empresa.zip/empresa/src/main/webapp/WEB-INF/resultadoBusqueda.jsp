<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultado de Búsqueda</title>
    <link rel="stylesheet" href="<c:url value='/styles/global.css'/>">
</head>
<body>
<header>
    <h1>Resultado de Búsqueda de Empleados</h1>
</header>

<main>
    <section class="tabla-container">

        <c:choose>
            <c:when test="${empty listaEmpleados}">
                <p class="mensaje">No se encontraron empleados con los criterios de búsqueda.</p>
            </c:when>

            <c:otherwise>
                <table class="tabla">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>DNI</th>
                            <th>Sexo</th>
                            <th>Categoría</th>
                            <th>Años trabajados</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="empleado" items="${listaEmpleados}">
                            <tr>
                                <td>${empleado.nombre}</td>
                                <td>${empleado.dni}</td>
                                <td>${empleado.sexo}</td>
                                <td>${empleado.categoria}</td>
                                <td>${empleado.anyos}</td>
                                <td>
                                    <a class="btn-small" href="<c:url value='/EmpleadosController?action=editar&dni=${empleado.dni}'/>">Editar</a>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </c:otherwise>
        </c:choose>

        <div class="acciones">
            <a href="<c:url value='/EmpleadosController?action=buscarForm'/>" class="btn-secundario">Nueva búsqueda</a>
            <a href="<c:url value='/EmpleadosController?action=listar'/>" class="btn-secundario">Volver al listado</a>
        </div>

    </section>
</main>

<footer>
    <p>© 2025 Gestión de Nóminas</p>
</footer>
</body>
</html>
