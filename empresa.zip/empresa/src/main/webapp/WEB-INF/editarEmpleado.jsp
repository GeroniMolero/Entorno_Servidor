<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Empleado</title>
    <link rel="stylesheet" href="<c:url value='/styles/global.css'/>">
</head>
<body>
<header>
    <h1>Editar Empleado</h1>
</header>

<main>
    <section class="form-container">
        <form action="<c:url value='/EmpleadosController?action=actualizar'/>" method="post" class="form-dark">

            <!-- DNI -->
            <label for="dni">DNI:</label>
            <input type="text" id="dni" name="dni" value="${empleado.dni}" readonly>

            <!-- Nombre -->
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="${empleado.nombre}" required>

            <!-- Sexo -->
            <p>Debug sexo: ${empleado.sexo}</p>
            <label for="sexo">Sexo:</label>
            <select id="sexo" name="sexo">
                <c:choose>
                    <c:when test="${empleado.sexo == 'M' || empleado.sexo == 'm'}">
                        <option value="M" selected>Masculino</option>
                        <option value="F">Femenino</option>
                    </c:when>
                    <c:when test="${empleado.sexo == 'F' || empleado.sexo == 'f'}">
                        <option value="M">Masculino</option>
                        <option value="F" selected>Femenino</option>
                    </c:when>
                    <c:otherwise>
                        <option value="M">Masculino</option>
                        <option value="F">Femenino</option>
                    </c:otherwise>
                </c:choose>
            </select>



            <!-- Categoría -->
            <label for="categoria">Categoría:</label>
            <input type="number" id="categoria" name="categoria" min="1" max="10" value="${empleado.categoria}" required>

            <!-- Años trabajados -->
            <label for="anyos">Años trabajados:</label>
            <input type="number" id="anyos" name="anyos" min="0" value="${empleado.anyos}" required>

            <!-- Botones -->
            <div class="acciones">
                <input type="submit" value="Guardar cambios" class="btn">
                <a href="<c:url value='/EmpleadosController?action=listar'/>" class="btn-secundario">Cancelar</a>
            </div>
        </form>
    </section>
</main>

<footer>
    <p>© 2025 Gestión de Nóminas — Aplicación Web desarrollada en Java EE con MVC</p>
</footer>
</body>
</html>
