<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultado del Salario</title>
    <link rel="stylesheet" href="<c:url value='/styles/global.css'/>">
</head>
<body>
    <header>
        <h1>Resultado del Cálculo de Salario</h1>
    </header>

    <main>
        <section class="resultado-container">
            <c:choose>
                <c:when test="${not empty error}">
                    <div class="error">${error}</div>
                </c:when>
                <c:otherwise>
                    <h2>Empleado: ${empleado.nombre}</h2>
                    <p><strong>DNI:</strong> ${empleado.dni}</p>
                    <p><strong>Categoría:</strong> ${empleado.categoria}</p>
                    <p><strong>Años trabajados:</strong> ${empleado.anyos}</p>
                    <p><strong>Salario calculado:</strong> 
                        <span style="color:#5cff8a; font-size:1.3em;">
                            ${salario} €
                        </span>
                    </p>
                </c:otherwise>
            </c:choose>

            <div class="acciones">
                <a href="<c:url value='/index.jsp'/>" class="btn-secundario">Volver al inicio</a>
                <a href="<c:url value='/EmpleadosController?action=listar'/>" class="btn-secundario">Ver empleados</a>
            </div>
        </section>
    </main>

    <footer>
        <p>© 2025 Gestión de Nóminas</p>
    </footer>
</body>
</html>
